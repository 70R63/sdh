/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 4, 2020 12:04:37 AM                     ---
 * ----------------------------------------------------------------
 */
package com.sdh.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedSdhbackofficeConstants
{
	public static final String EXTENSIONNAME = "sdhbackoffice";
	
	protected GeneratedSdhbackofficeConstants()
	{
		// private constructor
	}
	
	
}
